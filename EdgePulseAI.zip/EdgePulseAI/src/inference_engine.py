"""
EdgePulse AI — Inference Engine
AMD ROCm-powered GPU inference for real-time object detection
Team: ThreadRipper Rebels | AMD Slingshot 2026
"""

import torch
import time
import cv2
import numpy as np
from pathlib import Path


class InferenceEngine:
    """
    AMD ROCm-accelerated inference engine for real-time vision processing.
    Leverages AMD Radeon GPU via ROCm/HIP backend for maximum throughput.
    """

    def __init__(self, model_path: str = "yolov8n.pt", device: str = "rocm"):
        self.device = self._setup_device(device)
        self.model = self._load_model(model_path)
        self.inference_times = []
        print(f"[EdgePulse AI] Inference Engine initialized on: {self.device}")

    def _setup_device(self, device: str) -> torch.device:
        """Setup AMD ROCm GPU device."""
        if device == "rocm" and torch.cuda.is_available():
            # ROCm uses CUDA-compatible API
            selected = torch.device("cuda:0")
            print(f"[EdgePulse AI] AMD GPU detected: {torch.cuda.get_device_name(0)}")
        else:
            selected = torch.device("cpu")
            print("[EdgePulse AI] Falling back to CPU mode")
        return selected

    def _load_model(self, model_path: str):
        """Load and optimize model for AMD hardware."""
        try:
            from ultralytics import YOLO
            model = YOLO(model_path)
            model.to(self.device)
            print(f"[EdgePulse AI] Model loaded: {model_path}")
            return model
        except ImportError:
            print("[EdgePulse AI] ultralytics not found. Install with: pip install ultralytics")
            return None

    def preprocess_frame(self, frame: np.ndarray) -> np.ndarray:
        """Preprocess frame before inference (post-FPGA stage)."""
        # Resize to model input size
        frame_resized = cv2.resize(frame, (640, 640))
        # Normalize
        frame_normalized = frame_resized / 255.0
        return frame_normalized

    def run_inference(self, frame: np.ndarray) -> dict:
        """
        Run real-time inference on a single frame.
        Returns detected objects with bounding boxes and confidence scores.
        """
        if self.model is None:
            return {"error": "Model not loaded"}

        start_time = time.perf_counter()

        # Run YOLOv8 inference on AMD GPU via ROCm
        results = self.model(frame, device=self.device, verbose=False)

        end_time = time.perf_counter()
        inference_time_ms = (end_time - start_time) * 1000
        self.inference_times.append(inference_time_ms)

        # Parse detections
        detections = []
        for result in results:
            boxes = result.boxes
            if boxes is not None:
                for box in boxes:
                    detections.append({
                        "class": result.names[int(box.cls)],
                        "confidence": float(box.conf),
                        "bbox": box.xyxy[0].tolist()
                    })

        return {
            "detections": detections,
            "inference_time_ms": round(inference_time_ms, 2),
            "fps": round(1000 / inference_time_ms, 1),
            "device": str(self.device)
        }

    def run_video_stream(self, source: int = 0):
        """Process live video stream from camera in real-time."""
        cap = cv2.VideoCapture(source)
        print(f"[EdgePulse AI] Starting real-time video stream from camera {source}")

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            # Run inference
            result = self.run_inference(frame)

            # Draw detections
            frame = self._draw_detections(frame, result["detections"])

            # Display metrics
            cv2.putText(frame,
                        f"Latency: {result['inference_time_ms']}ms | FPS: {result['fps']}",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
            cv2.putText(frame,
                        f"Device: AMD ROCm GPU | Objects: {len(result['detections'])}",
                        (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 165, 0), 2)

            cv2.imshow("EdgePulse AI — Real-Time Detection", frame)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()
        self._print_stats()

    def _draw_detections(self, frame: np.ndarray, detections: list) -> np.ndarray:
        """Draw bounding boxes and labels on frame."""
        for det in detections:
            x1, y1, x2, y2 = [int(c) for c in det["bbox"]]
            label = f"{det['class']} {det['confidence']:.0%}"
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 165, 255), 2)
            cv2.putText(frame, label, (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 165, 255), 2)
        return frame

    def _print_stats(self):
        """Print performance statistics."""
        if self.inference_times:
            avg = np.mean(self.inference_times)
            print(f"\n[EdgePulse AI] Performance Summary:")
            print(f"  Average Latency : {avg:.2f}ms")
            print(f"  Average FPS     : {1000/avg:.1f}")
            print(f"  Total Frames    : {len(self.inference_times)}")


if __name__ == "__main__":
    engine = InferenceEngine(model_path="yolov8n.pt", device="rocm")
    engine.run_video_stream(source=0)
