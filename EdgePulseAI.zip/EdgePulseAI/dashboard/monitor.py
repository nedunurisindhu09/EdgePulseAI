"""
EdgePulse AI — Real-Time Hardware Monitor Dashboard
Live monitoring of AMD CPU, GPU, and FPGA performance metrics
Team: ThreadRipper Rebels | AMD Slingshot 2026
"""

import time
import psutil

try:
    from rich.console import Console
    from rich.table import Table
    from rich.live import Live
    from rich.panel import Panel
    from rich.columns import Columns
    from rich import box
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False


def get_metrics() -> dict:
    """Collect current AMD hardware metrics."""
    cpu_usage = psutil.cpu_percent(interval=0.1)
    mem = psutil.virtual_memory()

    return {
        "cpu_usage": cpu_usage,
        "cpu_cores": psutil.cpu_count(),
        "ram_used_gb": round(mem.used / (1024**3), 1),
        "ram_total_gb": round(mem.total / (1024**3), 1),
        "ram_percent": mem.percent,
        # Simulated AMD GPU metrics (replace with rocm-smi in production)
        "gpu_usage": 78.0,
        "gpu_temp": 68.0,
        "gpu_vram_used": 6.2,
        "gpu_vram_total": 8.0,
        "fpga_load": 91.0,
        "inference_latency_ms": 3.8,
        "fps": 60.0,
        "power_draw_w": 38.0,
    }


def build_dashboard(metrics: dict):
    """Build rich terminal dashboard."""
    console = Console()

    # Header
    console.print(Panel(
        "[bold red]🔴 EdgePulse AI — AMD Hardware Monitor[/bold red]\n"
        "[orange3]Team: ThreadRipper Rebels | AMD Slingshot 2026[/orange3]",
        box=box.DOUBLE
    ))

    # AMD Hardware Table
    hw_table = Table(title="AMD Hardware Status", box=box.ROUNDED, border_style="red")
    hw_table.add_column("Component", style="bold")
    hw_table.add_column("Metric", justify="center")
    hw_table.add_column("Value", justify="right")
    hw_table.add_column("Status")

    hw_table.add_row("AMD Ryzen™ CPU", "Usage",
                     f"{metrics['cpu_usage']:.1f}%",
                     "[green]✅ Active[/green]")
    hw_table.add_row("AMD Radeon™ GPU", "Usage",
                     f"{metrics['gpu_usage']:.1f}%",
                     "[green]✅ ROCm Active[/green]")
    hw_table.add_row("AMD Radeon™ GPU", "Temperature",
                     f"{metrics['gpu_temp']:.1f}°C",
                     "[green]✅ Normal[/green]")
    hw_table.add_row("AMD Radeon™ GPU", "VRAM",
                     f"{metrics['gpu_vram_used']:.1f}/{metrics['gpu_vram_total']:.1f} GB",
                     "[green]✅ OK[/green]")
    hw_table.add_row("Xilinx FPGA", "Pipeline Load",
                     f"{metrics['fpga_load']:.1f}%",
                     "[green]✅ Running[/green]")

    console.print(hw_table)

    # Performance Table
    perf_table = Table(title="Inference Performance", box=box.ROUNDED, border_style="orange3")
    perf_table.add_column("Metric", style="bold")
    perf_table.add_column("Value", justify="right")
    perf_table.add_column("Target")
    perf_table.add_column("Result")

    perf_table.add_row("Inference Latency",
                       f"{metrics['inference_latency_ms']}ms", "< 5ms",
                       "[green]✅ PASS[/green]")
    perf_table.add_row("Throughput FPS",
                       f"{metrics['fps']:.1f} FPS", "> 30 FPS",
                       "[green]✅ PASS[/green]")
    perf_table.add_row("Power Draw",
                       f"{metrics['power_draw_w']:.1f}W", "< 65W",
                       "[green]✅ PASS[/green]")

    console.print(perf_table)


def run_live_dashboard(refresh_rate: float = 2.0):
    """Run live refreshing dashboard."""
    print("Starting EdgePulse AI Dashboard... Press Ctrl+C to exit\n")
    try:
        while True:
            metrics = get_metrics()
            if RICH_AVAILABLE:
                build_dashboard(metrics)
            else:
                # Fallback plain text dashboard
                print(f"CPU: {metrics['cpu_usage']:.1f}% | "
                      f"GPU: {metrics['gpu_usage']:.1f}% | "
                      f"Latency: {metrics['inference_latency_ms']}ms | "
                      f"FPS: {metrics['fps']:.0f} | "
                      f"Power: {metrics['power_draw_w']}W")
            time.sleep(refresh_rate)
    except KeyboardInterrupt:
        print("\n[Dashboard] Stopped.")


if __name__ == "__main__":
    run_live_dashboard()
