"""
EdgePulse AI — Hardware-Aware Model Quantizer
Optimizes AI models specifically for AMD Ryzen NPU and Radeon GPU
Team: ThreadRipper Rebels | AMD Slingshot 2026
"""

import torch
import time
from pathlib import Path


class AMDModelQuantizer:
    """
    Hardware-aware quantization pipeline for AMD devices.
    Converts FP32 models → FP16 / INT8 for maximum AMD hardware efficiency.
    """

    def __init__(self, target_device: str = "radeon_gpu"):
        self.target_device = target_device
        print(f"[Quantizer] AMD Model Quantizer ready for: {target_device}")

    def quantize_to_fp16(self, model: torch.nn.Module) -> torch.nn.Module:
        """Convert model to FP16 for AMD Radeon GPU inference."""
        print("[Quantizer] Converting model to FP16 for AMD Radeon GPU...")
        model_fp16 = model.half()
        print("[Quantizer] ✅ FP16 quantization complete — 2x memory reduction")
        return model_fp16

    def quantize_to_int8(self, model: torch.nn.Module) -> torch.nn.Module:
        """Convert model to INT8 for AMD Ryzen NPU inference."""
        print("[Quantizer] Converting model to INT8 for AMD Ryzen NPU...")
        model_int8 = torch.quantization.quantize_dynamic(
            model, {torch.nn.Linear, torch.nn.Conv2d}, dtype=torch.qint8
        )
        print("[Quantizer] ✅ INT8 quantization complete — 4x memory reduction")
        return model_int8

    def benchmark_model(self, model, input_shape=(1, 3, 640, 640), runs=50) -> dict:
        """Benchmark model inference speed on AMD hardware."""
        dummy_input = torch.randn(input_shape)
        times = []

        print(f"[Quantizer] Benchmarking over {runs} runs...")
        with torch.no_grad():
            for _ in range(runs):
                start = time.perf_counter()
                _ = model(dummy_input)
                times.append((time.perf_counter() - start) * 1000)

        import statistics
        return {
            "avg_latency_ms": round(statistics.mean(times), 2),
            "min_latency_ms": round(min(times), 2),
            "max_latency_ms": round(max(times), 2),
            "avg_fps": round(1000 / statistics.mean(times), 1)
        }

    def get_model_size_mb(self, model: torch.nn.Module) -> float:
        """Calculate model size in MB."""
        total = sum(p.nelement() * p.element_size() for p in model.parameters())
        return round(total / (1024 ** 2), 2)


if __name__ == "__main__":
    quantizer = AMDModelQuantizer(target_device="radeon_gpu")
    print("[Quantizer] AMD Hardware-Aware Quantizer ready!")
    print("[Quantizer] Supported: FP32 → FP16 (Radeon GPU), FP32 → INT8 (Ryzen NPU)")
